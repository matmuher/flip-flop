.. cmake-module:: ../../Modules/CheckLinkerFlag.cmake
