double mysqrt(double x);
